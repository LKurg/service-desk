<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "user";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $hashedPassword = md5($password);

    $sql = "INSERT INTO users (username, password, registration_date) VALUES ('$username', '$hashedPassword', NOW())";

    if ($conn->query($sql) === TRUE) {
        header("Location: login.html");
        echo "Registration successful";
    } else {
        echo "Error registering user: " . $conn->error;
    }
}

$conn->close();
?>
