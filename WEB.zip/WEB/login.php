<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user";

$conn = new mysqli("localhost", "root", "", "user");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $hashedPassword = md5($password);

    $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$hashedPassword'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        header("Location: index.html");
        exit();
    } else {
        echo "Invalid username or password. Please try again.";
    }
}

$conn->close();
?>
